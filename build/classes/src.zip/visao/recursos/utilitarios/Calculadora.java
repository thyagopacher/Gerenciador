/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package visao.recursos.utilitarios;

import java.math.BigDecimal;
import java.util.regex.Pattern;
import javax.swing.JOptionPane;

/**
 *
 * @author Thyago
 */
public class Calculadora {

      public String calculaPorcentagem(double ppeca, int cpeca){
          String res = "";
          try{
              double r = (cpeca) * (ppeca/100) + cpeca;
              r        = arredonta((r));
              res      = Validacao.formatMoeda(r);
          }catch(Exception ex){
              JOptionPane.showMessageDialog(null, "Erro ao realizar o cálculo da porcentagem causado por:\n" + ex);
          }
          return res;
      }
      
      public double calculaPorcentagem2(double ppeca, int cpeca){
          double res = 0;
          try{
              double r = (cpeca) * (ppeca/100) + cpeca;
              r        = arredonta((r));
              res      = r;
          }catch(Exception ex){
              JOptionPane.showMessageDialog(null, "Erro ao realizar o cálculo da porcentagem causado por:\n" + ex);
          }
          return res;
      }      
      
      public double calculaPorcentagem2(double ppeca, double cpeca){
          double res = 0;
          try{
              double r = (cpeca) * (ppeca/100) + cpeca;
              r        = arredonta((r));
              res      = r;
          }catch(Exception ex){
              JOptionPane.showMessageDialog(null, "Erro ao realizar o cálculo da porcentagem causado por:\n" + ex);
          }
          return res;
      }          

      public double calculaPorcentagem3(double porcentagem, double valor){
          double res = 0;
          try{
              double r = (valor) * (porcentagem/100);
              r        = arredonta((r));
              res      = r;
          }catch(Exception ex){
              JOptionPane.showMessageDialog(null, "Erro ao realizar o cálculo da porcentagem causado por:\n" + ex);
          }
          return res;
      }      

      public double arredonta(double res){ 
            BigDecimal bd           = new BigDecimal(Double.valueOf(res));  
            bd                      = bd.setScale(2,BigDecimal.ROUND_HALF_UP);  
            res                     = bd.doubleValue(); 
            String     r            = String.valueOf(res);
            String[]   t            = r.split (Pattern.quote (".")); 
            int        p1           = Integer.valueOf(t[0]);
            int        p2           = Integer.valueOf((t[1]));

            if(p2 <= 3){
                p2 = 0;
            }else{
                if(p2 > 6){
                  p2 = 0;
                  p1 += 1;                  
                }else{
                  if(p2 >= 4 && p2 <= 6){
                    p2 = 5;
                  }
                }
            }

            String r2  = String.valueOf(p1) + "." + String.valueOf(p2);
            return Double.valueOf(r2);
      }

}
